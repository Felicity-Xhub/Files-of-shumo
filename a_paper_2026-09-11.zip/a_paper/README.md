# 当前论文与源码备份

论文题目：**考虑变物性与径向收缩的药材烘干模型**。

这份备份来自 `Downloads/a_paper`，用于队员查看当前论文、继续编辑以及出现问题时恢复。正文和图像按现有文件原样保存。

- **直接阅读：[main.pdf](main.pdf)**。本次 PDF 为 2026-09-11 21:30（北京时间）导出的 28 页版本。
- **编辑入口：[main.tex](main.tex)**。各章节位于 [sections/](sections/)，结果表格位于 [tables/](tables/)，正文插图位于 [figures/](figures/)。
- [preamble.tex](preamble.tex) 定义排版和宏命令，[results.tex](results.tex) 保存入口加载的结果宏。

## 程序和数据在哪里

本次提供的 `a_paper` 文件夹没有独立求解程序。仓库已有的四问交付目录继续保存程序、输入数据、结果表和运行说明：

| 问题 | 求解程序 | 运行说明与材料 |
| --- | --- | --- |
| 第一问 | [q1_model_solve.py](../第一问交付材料/q1_model_solve.py) | [第一问交付材料](../第一问交付材料/) |
| 第二问 | [q2_model_solve.py](../第二问交付材料/q2_model_solve.py) | [第二问交付材料](../第二问交付材料/) |
| 第三问 | [q3_model_solve.py](../第三问交付材料/q3_model_solve.py) | [第三问交付材料](../第三问交付材料/) |
| 第四问 | [q4_model_solve.py](../第四问交付材料/q4_model_solve.py) | [第四问交付材料](../第四问交付材料/) |

上述链接指向仓库现有程序；本次备份没有重新运行求解程序，也未重新核验其结果与全文数字的对应关系。

## 如何导出 PDF

安装包含 `ctex` 和 Fandol 字体的 TeX 发行版（例如 MacTeX 或 TeX Live）。在本目录内使用 **XeLaTeX** 编译 `main.tex` 两次，让交叉引用稳定：

```sh
xelatex -interaction=nonstopmode -file-line-error main.tex
xelatex -interaction=nonstopmode -file-line-error main.tex
```

使用 VS Code 时，打开整个 `a_paper` 文件夹，选择 XeLaTeX 编译配方即可。需要修改论文时，应连同新导出的 `main.pdf` 一起提交 Git，便于队员核对。

## 本次存档范围

保存主 PDF、当前入口实际引用的 LaTeX 源文件、六张表的源码和五张正文图片。旧的 `paper_single` 版本、未引用的旧章节占位文件、编译日志和临时文件未纳入此次上传。

这是当前草稿备份，参考文献和附录中仍保留原有待补内容。本次不修改论文正文或结果。
